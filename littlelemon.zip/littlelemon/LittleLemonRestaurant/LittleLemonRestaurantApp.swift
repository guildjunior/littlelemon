//
//  LittleLemonRestaurantApp.swift
//  LittleLemonRestaurant
//
//  Created by Guild Junior on 24/05/23.
//

import SwiftUI

@main
struct LittleLemonRestaurantApp: App {
    var body: some Scene {
        WindowGroup {
            Onboarding()
        }
    }
}
